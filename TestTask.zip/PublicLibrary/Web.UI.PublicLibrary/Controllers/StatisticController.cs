﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Helpers;
using PL.DAL.Repository;
using PL.Domain.Repository;
using Web.UI.PublicLibrary.Utils.Charts;

namespace Web.UI.PublicLibrary.Controllers
{
    public class StatisticController : Controller
    {
        #region private constants
        private const int COUNT_VALUES = 20;
        #endregion

        #region private variables
        private IStatistic<PL.DAL.Models.Statistic> repository;
        #endregion

        public StatisticController(IStatistic<PL.DAL.Models.Statistic> repository)
        {
            this.repository = repository;
        }

        public ActionResult Statistic()
        {
            var statistic = repository.GetAll();
            return View(statistic.OrderBy(i => i.SendResponseTime).Skip(statistic.Count() - COUNT_VALUES));
        }

        public FileContentResult ShowChart()
        {
            var chart = new ChartMaker();
            var statistic = repository.GetAll();
            return chart.MakeChart(statistic.OrderBy(i=>i.SendResponseTime).Skip(statistic.Count() - COUNT_VALUES), "Response Time");
        }

    }
}