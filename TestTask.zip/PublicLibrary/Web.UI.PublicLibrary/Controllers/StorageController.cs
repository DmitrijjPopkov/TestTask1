﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PL.DAL.Repository;
using PL.Domain.Repository;

namespace Web.UI.PublicLibrary.Controllers
{
    public class StorageController : Controller
    {
        #region private variables
        private IDepartment<PL.DAL.Models.Department> departmentRepository;
        private IBook<PL.DAL.Models.Book> bookRepository;
        #endregion

        public StorageController(IDepartment<PL.DAL.Models.Department> departmentRepository, IBook<PL.DAL.Models.Book> bookRepository)
        {
            this.departmentRepository = departmentRepository;
            this.bookRepository = bookRepository;
        }

        public ActionResult Departments(Guid departmentID)
        {
            ViewBag.DepartmentId = departmentID;
            var books = bookRepository.GetAll().Where(b=>b.DepartmentID == departmentID);

            return View(books);
        }

        public ActionResult EditDepartments()
        {
            return View(departmentRepository.GetAll());
        }

        public ActionResult EditDepartment(Guid departmentId)
        {
            return View(departmentRepository.Get(departmentId));
        }

        public ActionResult CreateDepartment()
        {
            Guid id = Guid.NewGuid();
            departmentRepository.Add(new PL.DAL.Models.Department() { Id = id, Name = "New department" });
            return RedirectToAction("EditDepartment", new { @departmentId = id });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EditDepartment(PL.DAL.Models.Department department)
        {
            if (ModelState.IsValid)
            {
                departmentRepository.Edit(department);
            }
            return RedirectToAction("EditDepartments");
        }

        public ActionResult Details(Guid id)
        {
            return RedirectToAction("Departments", new { departmentID = id });
        }

        public ActionResult CreateDetails(Guid departmentId)
        {
            ViewBag.DepartmentId = departmentId;
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CreateDetails(PL.DAL.Models.Book book, Guid departmentId)
        {
            if (ModelState.IsValid)
            {
                book.Id = Guid.NewGuid();

                var department = departmentRepository.Get(departmentId);
                if (department.Books == null)
                {
                    department.Books = new List<PL.DAL.Models.Book>();
                }

                department.Books.Add(book);

                departmentRepository.Edit(department);
            }
            return RedirectToAction("EditDepartments");
        }
    }
}