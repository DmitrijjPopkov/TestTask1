﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MvcSiteMapProvider;
using PL.DAL.Repository;

namespace Web.UI.PublicLibrary.Utils.Providers
{
    public class StorageDinamicProvider : DynamicNodeProviderBase
    {
        #region private variables
        private Department department;
        #endregion

        public StorageDinamicProvider()
        {
            department = new Department();
        }

        public override IEnumerable<DynamicNode> GetDynamicNodeCollection(ISiteMapNode node)
        {
            var nodes = new List<DynamicNode>();
            var departments = department.GetAll();

            foreach (var item in departments)
            {
                DynamicNode dinamicNode = new DynamicNode();

                dinamicNode.Key = item.Id.ToString();
                dinamicNode.Title = item.Name;
                dinamicNode.RouteValues.Add("departmentID", item.Id);
                dinamicNode.Controller = "Storage";
                dinamicNode.Action = "Departments";
                nodes.Add(dinamicNode);
            }

            return nodes;
        }

    }
}