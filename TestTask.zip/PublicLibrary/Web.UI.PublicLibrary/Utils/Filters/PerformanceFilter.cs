﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Diagnostics;
using PL.DAL.Repository;

namespace Web.UI.PublicLibrary.Utils.Filters
{
    public class PerformanceFilter : IActionFilter
    {
        #region private variables
        private Stopwatch counter;
        private Statistic statisticRepository;
        #endregion

        public PerformanceFilter()
        {
            counter = new Stopwatch();
            statisticRepository = new Statistic();
        }

        public void OnActionExecuting(ActionExecutingContext filterContext)
        {
            counter.Reset();
            counter.Start();
        }

        public void OnActionExecuted(ActionExecutedContext filterContext)
        {
            counter.Stop();
            var responseTime = counter.ElapsedMilliseconds;

            string currentAction = (string)filterContext.RouteData.Values["action"];

            statisticRepository.Add(new PL.DAL.Models.Statistic() { Id = Guid.NewGuid(), ResponseTime = (int)responseTime, SendResponseTime = DateTime.Now, PageName = currentAction });
        }
    }
}