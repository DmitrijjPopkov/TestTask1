﻿using Autofac;
using Autofac.Core;
using Autofac.Integration.Mvc;
using PL.DAL.Repository;
using PL.Domain.Repository;
using System.Web.Mvc;


namespace Web.UI.PublicLibrary.Utils.AutoFacConfig
{
    public class AutofacConfig
    {
        public static void ConfigureContainer()
        {
            var builder = new ContainerBuilder();

            builder.RegisterControllers(typeof(MvcApplication).Assembly);

            builder.RegisterType<Book>().As<PL.Domain.Repository.IBook<PL.DAL.Models.Book>>();
            builder.RegisterType<Statistic>().As<PL.Domain.Repository.IStatistic<PL.DAL.Models.Statistic>>();
            builder.RegisterType<Department>().As<PL.Domain.Repository.IDepartment<PL.DAL.Models.Department>>();

            var container = builder.Build();

            DependencyResolver.SetResolver(new AutofacDependencyResolver(container));
        }
    }
}