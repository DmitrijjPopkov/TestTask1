﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PL.DAL.Models;
using System.Web.Helpers;
using System.IO;
using System.Drawing;

namespace Web.UI.PublicLibrary.Utils.Charts
{
    public class ChartMaker
    {
        public FileContentResult MakeChart(IEnumerable<Statistic> data, string title)
        {
            var chart = new System.Web.UI.DataVisualization.Charting.Chart();
            chart.Width = 1000;
            chart.Height = 400;

            chart.BackColor = Color.FromArgb(211, 223, 240);
            chart.BorderlineDashStyle = System.Web.UI.DataVisualization.Charting.ChartDashStyle.Solid;
            chart.BackSecondaryColor = Color.White;
            chart.BackGradientStyle = System.Web.UI.DataVisualization.Charting.GradientStyle.TopBottom;
            chart.BorderlineWidth = 1;
            chart.Palette = System.Web.UI.DataVisualization.Charting.ChartColorPalette.BrightPastel;
            chart.BorderlineColor = Color.FromArgb(26, 59, 105);
            chart.RenderType = System.Web.UI.DataVisualization.Charting.RenderType.BinaryStreaming;
            chart.BorderSkin.SkinStyle = System.Web.UI.DataVisualization.Charting.BorderSkinStyle.Emboss;
            chart.AntiAliasing = System.Web.UI.DataVisualization.Charting.AntiAliasingStyles.All;
            chart.TextAntiAliasingQuality = System.Web.UI.DataVisualization.Charting.TextAntiAliasingQuality.Normal;

            chart.Titles.Add(title);
            chart.Legends.Add(CreateLegend());
            chart.Series.Add(CreateSeries(data));
            chart.ChartAreas.Add(CreateChartArea());

            var ms = new MemoryStream();
            chart.SaveImage(ms);

            return new FileContentResult(ms.GetBuffer(), @"image/png");

        }

        private System.Web.UI.DataVisualization.Charting.Series CreateSeries(IEnumerable<Statistic> data)
        {
            var series = new System.Web.UI.DataVisualization.Charting.Series();

            series.ChartType = System.Web.UI.DataVisualization.Charting.SeriesChartType.Line;
            series.Name = "Response time";
            series.Color = Color.FromArgb(29, 50, 230);

            foreach (var item in data)
            {
                System.Web.UI.DataVisualization.Charting.DataPoint point = new System.Web.UI.DataVisualization.Charting.DataPoint();
                point.AxisLabel = item.SendResponseTime.ToString();
                point.YValues = new double[] { item.ResponseTime };
                series.Points.Add(point);
            }

            SetMinMaxLabel(data, series);
            return series;
        }

        private System.Web.UI.DataVisualization.Charting.ChartArea CreateChartArea()
        {
            var chartArea = new System.Web.UI.DataVisualization.Charting.ChartArea();
            chartArea.AxisX.IsLabelAutoFit = true;
            chartArea.AxisY.IsLabelAutoFit = true;
            chartArea.BackColor = Color.Transparent;

            chartArea.AxisY.LineColor = Color.FromArgb(64, 64, 64, 64);
            chartArea.AxisX.LineColor = Color.FromArgb(64, 64, 64, 64);
            chartArea.AxisY.MajorGrid.LineColor = Color.FromArgb(64, 64, 64, 64);
            chartArea.AxisX.MajorGrid.LineColor = Color.FromArgb(64, 64, 64, 64);

            chartArea.AxisX.Interval = 1;
            return chartArea;
        }

        private System.Web.UI.DataVisualization.Charting.Legend CreateLegend()
        {
            var legend = new System.Web.UI.DataVisualization.Charting.Legend();
            legend.Name = "Response time";
            legend.Docking = System.Web.UI.DataVisualization.Charting.Docking.Bottom;
            legend.Alignment = StringAlignment.Center;
            legend.BackColor = Color.Transparent;
            legend.Font = new Font(new FontFamily("Trebuchet MS"), 9);
            legend.LegendStyle = System.Web.UI.DataVisualization.Charting.LegendStyle.Row;

            return legend;
        }

        private void SetMinMaxLabel(IEnumerable<Statistic> data, System.Web.UI.DataVisualization.Charting.Series series)
        {
            series.IsValueShownAsLabel = true;

            var min = data.OrderBy(i => i.ResponseTime).FirstOrDefault();
            var max = data.OrderBy(i => i.ResponseTime).LastOrDefault();

            foreach (var point in series.Points)
            {
                if (Convert.ToInt32(point.YValues[0]) == min.ResponseTime)
                {
                    point.LabelForeColor = Color.White; 
                    point.LabelBackColor= Color.FromArgb(16, 142, 12);
                }
                else
                {
                    if (Convert.ToInt32(point.YValues[0]) == max.ResponseTime)
                    {
                        point.LabelForeColor = Color.White;
                        point.LabelBackColor = Color.FromArgb(255, 0, 0);
                    }
                }
            }
        }
    }
}