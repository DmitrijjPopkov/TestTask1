﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace PL.DAL.Models
{
    public class Book
    {
        #region property
        public Guid Id { get; set; }
        public string Author { get; set; }
        public string Name { get; set; }
        public Department Department { get; set; }
        public Guid DepartmentID { get; set; }
        #endregion
    }
}
