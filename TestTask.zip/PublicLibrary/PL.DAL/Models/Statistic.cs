﻿using System;
using System.ComponentModel.DataAnnotations;

namespace PL.DAL.Models
{
    public class Statistic
    {
        #region property
        [Key]
        public Guid Id { get; set; }
        public int ResponseTime { get; set; }
        public DateTime SendResponseTime { get; set; }
        public string PageName { get; set; }
        #endregion
    }
}
