﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace PL.DAL.Models
{
    public class Department
    {
        #region property
        [Key]
        public Guid Id { get; set; }
        public string Name { get; set; }
        public List<Book> Books { get; set; }
        #endregion
    }
}
