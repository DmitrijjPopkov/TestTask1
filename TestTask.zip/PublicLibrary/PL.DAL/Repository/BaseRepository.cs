﻿using PL.DAL.Context;
using PL.Domain.Repository;
using System.Collections.Generic;
using System;

namespace PL.DAL.Repository
{
    public class BaseRepository<TEntity> : IRepository<TEntity> where TEntity : class
    {
        #region private variables
        private PLContext context;
        #endregion


        public BaseRepository()
        {
            context = new PLContext();
        }

        public void Add(TEntity item)
        {
            context.Set<TEntity>().Add(item);
            SaveChange();
        }

        public IEnumerable<TEntity> GetAll()
        {
            return context.Set<TEntity>();
        }

        public TEntity Get(Guid id)
        {
            return context.Set<TEntity>().Find(id);
        }

        public void Delete()
        {

        }

        public void Edit(TEntity item)
        {
            context.Set<TEntity>().Attach(item);
            context.Entry(item).State = System.Data.Entity.EntityState.Modified;
            SaveChange();
        }

        public void SaveChange()
        {
            context.SaveChanges();
        }
    }
}
