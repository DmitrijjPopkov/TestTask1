﻿using PL.Domain.Repository;

namespace PL.DAL.Repository
{
   public class Department: BaseRepository<PL.DAL.Models.Department>, IDepartment<PL.DAL.Models.Department>
    {
    }
}
