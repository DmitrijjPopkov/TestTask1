﻿using PL.Domain.Repository;

namespace PL.DAL.Repository
{
   public class Book: BaseRepository<PL.DAL.Models.Book>, PL.Domain.Repository.IBook<PL.DAL.Models.Book>
    {
    }
}
