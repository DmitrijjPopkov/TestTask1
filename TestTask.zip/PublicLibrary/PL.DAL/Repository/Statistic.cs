﻿using PL.Domain.Repository;


namespace PL.DAL.Repository
{
    public class Statistic : BaseRepository<PL.DAL.Models.Statistic>, IStatistic<PL.DAL.Models.Statistic>
    {
    }
}
