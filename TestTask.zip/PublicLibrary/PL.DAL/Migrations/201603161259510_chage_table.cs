namespace PL.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class chage_table : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Books", "Department_Id", "dbo.Departments");
            DropIndex("dbo.Books", new[] { "Department_Id" });
            AddColumn("dbo.Books", "Department_Id1", c => c.Guid());
            AlterColumn("dbo.Books", "Department_Id", c => c.Guid(nullable: false));
            CreateIndex("dbo.Books", "Department_Id1");
            AddForeignKey("dbo.Books", "Department_Id1", "dbo.Departments", "Id");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Books", "Department_Id1", "dbo.Departments");
            DropIndex("dbo.Books", new[] { "Department_Id1" });
            AlterColumn("dbo.Books", "Department_Id", c => c.Guid());
            DropColumn("dbo.Books", "Department_Id1");
            CreateIndex("dbo.Books", "Department_Id");
            AddForeignKey("dbo.Books", "Department_Id", "dbo.Departments", "Id");
        }
    }
}
