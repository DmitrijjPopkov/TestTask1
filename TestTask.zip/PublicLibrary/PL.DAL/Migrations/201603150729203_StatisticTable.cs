namespace PL.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class StatisticTable : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Statistics",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                        ResponseTime = c.Int(nullable: false),
                        SendResponseTime = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Statistics");
        }
    }
}
