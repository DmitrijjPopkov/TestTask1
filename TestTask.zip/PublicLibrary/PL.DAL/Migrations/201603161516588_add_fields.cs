namespace PL.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class add_fields : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Books", "Department_Id", "dbo.Departments");
            DropIndex("dbo.Books", new[] { "Department_Id" });
            RenameColumn(table: "dbo.Books", name: "Department_Id", newName: "DepartmentID");
            AlterColumn("dbo.Books", "DepartmentID", c => c.Guid(nullable: false));
            CreateIndex("dbo.Books", "DepartmentID");
            AddForeignKey("dbo.Books", "DepartmentID", "dbo.Departments", "Id", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Books", "DepartmentID", "dbo.Departments");
            DropIndex("dbo.Books", new[] { "DepartmentID" });
            AlterColumn("dbo.Books", "DepartmentID", c => c.Guid());
            RenameColumn(table: "dbo.Books", name: "DepartmentID", newName: "Department_Id");
            CreateIndex("dbo.Books", "Department_Id");
            AddForeignKey("dbo.Books", "Department_Id", "dbo.Departments", "Id");
        }
    }
}
