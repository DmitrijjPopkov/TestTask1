namespace PL.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class remove_field : DbMigration
    {
        public override void Up()
        {
            DropIndex("dbo.Books", new[] { "Department_Id1" });
            DropColumn("dbo.Books", "Department_Id");
            RenameColumn(table: "dbo.Books", name: "Department_Id1", newName: "Department_Id");
            AlterColumn("dbo.Books", "Department_Id", c => c.Guid());
            CreateIndex("dbo.Books", "Department_Id");
        }
        
        public override void Down()
        {
            DropIndex("dbo.Books", new[] { "Department_Id" });
            AlterColumn("dbo.Books", "Department_Id", c => c.Guid(nullable: false));
            RenameColumn(table: "dbo.Books", name: "Department_Id", newName: "Department_Id1");
            AddColumn("dbo.Books", "Department_Id", c => c.Guid(nullable: false));
            CreateIndex("dbo.Books", "Department_Id1");
        }
    }
}
