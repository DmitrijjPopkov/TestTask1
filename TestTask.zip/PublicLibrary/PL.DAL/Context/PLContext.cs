﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using PL.DAL.Models;

namespace PL.DAL.Context
{
    public class PLContext : DbContext
    {

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Book>()
                        .HasRequired<Department>(s => s.Department)
                        .WithMany(s => s.Books)
                        .HasForeignKey(s => s.DepartmentID);

        }

        #region property
        public DbSet<Statistic> Statistic { get; set; }
        public DbSet<Department> Departments { get; set; }
        public DbSet<Book> Books { get; set; }
        #endregion
    }
}
