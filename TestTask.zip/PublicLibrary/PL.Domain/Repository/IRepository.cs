﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PL.Domain.Repository
{
    public interface IRepository<TEntity> where TEntity : class
    {
        void Add(TEntity item);
        IEnumerable<TEntity> GetAll();
        TEntity Get(Guid id);
        void Edit(TEntity item);
        void Delete();
        void SaveChange();
    }
}
