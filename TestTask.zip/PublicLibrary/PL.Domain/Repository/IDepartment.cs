﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PL.Domain.Repository
{
    public interface IDepartment<TEntity> : IRepository<TEntity> where TEntity : class
    {
    }
}
