﻿var vals = $('tr td#Response_Time').map(function () {
    return parseInt($(this).text(), 10) ? parseInt($(this).text(), 10)
    : null;
}).get();

var min = Math.min.apply(Math, vals);
var max = Math.max.apply(Math, vals);

$('tr td#Response_Time').filter(function () {
    return parseInt($(this).text(), 10) === min;
}).addClass('min_value');

$('tr td#Response_Time').filter(function () {
    return parseInt($(this).text(), 10) === max;
}).addClass('max_value');